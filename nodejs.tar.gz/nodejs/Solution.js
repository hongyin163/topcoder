class Solution {
	/**
	 * 初始化
	 * 
	 * @param tempDir 可读写的临时目录
	 */
	init(tempDir) {
		// TODO: 可以在此处初始化一些数据结构
	}

	/**
	 * 处理输入文件
	 * 
	 * @param {String} inputPath 输入文件路径
	 * @param {Function} addSet 输出结果
	 * @return {Promise} 
	 */
	async process(inputPath, addSet) {
		//TODO:实现主体逻辑

		//示例输出: addSet(['aa','bb','cc'])


	}
}

module.exports = Solution;